from setuptools import setup

setup(
    name="test",
    version=0.1,
    author='harry_lucas',
    author_email='linly@hdinvesting.cn',
    maintainer='linly',
    maintainer_email='linly@hdinvesting.cn',
    description='test python package.',
    scripts=[r"script/test.py"]
)
